# importing the necessary dependencies
from flask import Flask, jsonify, request, make_response, render_template
from flask_cors import CORS, cross_origin
import pandas as pd
import numpy as np
import sklearn
import pickle
import json

app = Flask(__name__)  # initializing a flask app


'''
@app.route("/")
@cross_origin()
def home():
    return render_template("home.html")
'''


@app.route("/predict_departure_delay", methods=["POST"])
@cross_origin()
def departure_from_postman():

    try:

        # JSON Object in form of dictionary as Input
        content = request.get_json()
        print(content)
        # Dictionary to Dataframe
        df = pd.DataFrame(content)
        print(df)

        # We have the dataframe we want to predict delays about. Now let's do preprocessing on this dataframe.

        # convertion of object type to date type
        df['Date'] = pd.to_datetime(df['Date'])

        # Extracting Month,Year from 'Date' column
        df['year'] = df['Date'].dt.year
        df['month'] = df['Date'].dt.month
        # print(df.head())

        # year column should be categorical not numeric.
        # print(df.dtypes)
        df['year'] = df['year'].astype('object')

        # drop the Date column
        df.drop('Date', axis=1, inplace=True)

        # drop the Expected Departure Time, Expected Arrival Time as we don't use it in the prediction
        df.drop(['Expected Departure Time', 'Expected Arrival Time'],
                axis=1, inplace=True)

        # print(df.columns)

        # Add 3 extra columns (with zeros) because our OneHotEncoder and other Encoders were fitted on a dataset which had these 3 extra columns
        n = df.shape[0]
        duration_converted = [0] * n
        arrival_delay_converted = [0] * n
        departure_delay_converted = [0] * n

        # adding the lists to the dataframe as column
        df['duration_converted'] = duration_converted
        df['arrival_delay_converted'] = arrival_delay_converted
        df['departure_delay_converted'] = departure_delay_converted

        # Applying One Hot Encoding on 'Carrier','Airplane Type','Departure Airport', 'Arrival Airport' and 'year' columns using the saved OneHotEncoder Model

        # load the model from disk
        filename = "./models/departure delay/departure_onehotencoder.pickle"
        loaded_ohe = pickle.load(open(filename, 'rb'))

        # Now we just need to transform the new data.
        df = loaded_ohe.transform(df)

        # print(df.columns)

        # Mean Encoding on Month Column

        # load the model from disk
        filename = "./models/departure delay/departure_targetencoder.pickle"
        loaded_te = pickle.load(open(filename, 'rb'))

        # Now we just need to transform the new data.
        df = loaded_te.transform(df)

        # print(df['month'])

        # rename the month column as our models have a different name of this column
        df.rename(columns={'month': 'month_encoded'}, inplace=True)

        # Dropping arrival_delay_converted, duration_converted columns as they cannot be used as a feature for predicting departure delay
        df.drop(['arrival_delay_converted', 'duration_converted'],
                axis=1, inplace=True)

        # print(df.columns)

        # Dropping Target Column we inserted before Prediction
        df.drop(['departure_delay_converted'], axis=1, inplace=True)

        # Transform all these 20 Numerical features (using saved StandardScaler Object)

        num_cols = ['month_encoded',
                    'D_DewPointC', 'D_WindGustKmph', 'D_cloudcover', 'D_humidity', 'D_precipMM', 'D_pressure', 'D_tempC', 'D_visibility', 'D_winddirDegree', 'D_windspeedKmph',
                    'A_DewPointC', 'A_WindGustKmph', 'A_cloudcover', 'A_humidity', 'A_precipMM', 'A_pressure', 'A_tempC', 'A_visibility', 'A_winddirDegree', 'A_windspeedKmph',
                    ]

        # load the model from disk
        filename = "./models/departure delay/departure_standardscaler.pickle"
        loaded_standardscaler = pickle.load(open(filename, 'rb'))

        # Now we just need to transform the new data.
        # apply standardization on numerical features only
        df[num_cols] = loaded_standardscaler.transform(df[num_cols])
        # print(df.loc[0])  # test 1st row

        # df.to_csv("df.csv", index=False)

        # Load the model and Get the Prediction

        filename = './models/departure delay/departure_delay_rf_tuned_final.sav'
        # loading the model file from the storage
        loaded_model = pickle.load(open(filename, 'rb'))

        # pass to model to get prediction
        prediction = loaded_model.predict(
            df
        )

        # returning single prediction result to API CALLER
        # return jsonify({'Prediction': prediction[0]})

        # Returning full array of predictions to API CALLER
        response = {'prediction': []}
        response['prediction'] = list(prediction)
        return make_response(jsonify(response), 200)

    except Exception as e:
        print('The Exception message is: ', e)
        return 'something is wrong'


@app.route("/predict_arrival_delay", methods=["POST"])
@cross_origin()
def arrival_from_postman():
    try:
        # JSON Object in form of dictionary as Input
        content = request.get_json()
        print(content)
        # Dictionary to Dataframe
        df = pd.DataFrame(content)
        print(df)

        # We have the dataframe we want to predict delays about. Now let's do preprocessing on this dataframe.

        # convertion of object type to date type
        df['Date'] = pd.to_datetime(df['Date'])

        # Extracting Month,Year from 'Date' column
        df['year'] = df['Date'].dt.year
        df['month'] = df['Date'].dt.month
        # print(df.head())

        # year column should be categorical not numeric.
        # print(df.dtypes)
        df['year'] = df['year'].astype('object')

        # drop the Date column
        df.drop('Date', axis=1, inplace=True)

        # Extract Duration from Expected Departure Time and Expected Arrival Time

        expected_departure_time_converted = pd.DatetimeIndex(
            df['Expected Departure Time'])  # convert to 'datetimeindex'

        expected_departure_time_converted = expected_departure_time_converted.hour * \
            60 + expected_departure_time_converted.minute  # conversion to minutes

        expected_arrival_time_converted = pd.DatetimeIndex(
            df['Expected Arrival Time'])  # convert to 'datetimeindex'

        expected_arrival_time_converted = expected_arrival_time_converted.hour * \
            60 + expected_arrival_time_converted.minute  # conversion to minutes

        # get duration (in minutes) from above 2 columns
        df['duration_converted'] = expected_arrival_time_converted - \
            expected_departure_time_converted

        # Extract Departure Delay from Expected and Actual Departure Time

        expected_departure_time_converted = pd.DatetimeIndex(
            df['Expected Departure Time'])  # convert to 'datetimeindex'

        expected_departure_time_converted = expected_departure_time_converted.hour * \
            60 + expected_departure_time_converted.minute

        actual_departure_time_converted = pd.DatetimeIndex(
            df['Departure Time'])  # convert to 'datetimeindex'

        actual_departure_time_converted = actual_departure_time_converted.hour * \
            60 + actual_departure_time_converted.minute

        # get departure delay (in minutes) from above 2 columns
        df['departure_delay_converted'] = actual_departure_time_converted - \
            expected_departure_time_converted

        # Drop Expected and Actual Departure and Arrival Times as we don't use these in the prediction
        df.drop(['Expected Departure Time', 'Departure Time',
                 'Expected Arrival Time'], axis=1, inplace=True)

        # print(df.loc[0])

        # print(df.columns)

        # Add 1 extra column (with zeros) because our OneHotEncoder and other Encoders were fitted on a dataset which had this column (It is the target column actually)
        n = df.shape[0]
        arrival_delay_converted = [0] * n
        # adding the list to the dataframe as column
        df['arrival_delay_converted'] = arrival_delay_converted

        # Applying One Hot Encoding on 'Carrier','Airplane Type','Departure Airport', 'Arrival Airport' and 'year' columns using the saved OneHotEncoder Model

        # load the model from disk
        filename = "./models/arrival delay/arrival_onehotencoder.pickle"
        loaded_ohe = pickle.load(open(filename, 'rb'))

        # Now we just need to transform the new data.
        df = loaded_ohe.transform(df)

        print(df.columns)

        # Mean Encoding on Month Column

        # print(df['month'])

        # load the model from disk
        filename = "./models/arrival delay/arrival_targetencoder.pickle"
        loaded_te = pickle.load(open(filename, 'rb'))

        # Now we just need to transform the new data.
        df = loaded_te.transform(df)

        # print(df['month'])

        # rename the month column as our models have a different name of this column
        df.rename(columns={'month': 'month_encoded'}, inplace=True)

        # print(df.columns)

        # Dropping Target Column we inserted before Prediction
        df.drop(['arrival_delay_converted'], axis=1, inplace=True)

        # Transform all these 23 Numerical features (using saved StandardScaler Object)

        num_cols = ['month_encoded',
                    'D_DewPointC', 'D_WindGustKmph', 'D_cloudcover', 'D_humidity', 'D_precipMM', 'D_pressure', 'D_tempC', 'D_visibility', 'D_winddirDegree', 'D_windspeedKmph',
                    'A_DewPointC', 'A_WindGustKmph', 'A_cloudcover', 'A_humidity', 'A_precipMM', 'A_pressure', 'A_tempC', 'A_visibility', 'A_winddirDegree', 'A_windspeedKmph',
                    'duration_converted', 'departure_delay_converted', ]

        # load the model from disk
        filename = "./models/arrival delay/arrival_standardscaler.pickle"
        loaded_standardscaler = pickle.load(open(filename, 'rb'))

        # Now we just need to transform the new data.
        # apply standardization on numerical features only
        df[num_cols] = loaded_standardscaler.transform(df[num_cols])
        print(df.loc[0])  # test 1st row

        #df.to_csv("df.csv", index=False)

        # Load the model and Get the Prediction

        filename = './models/arrival delay/arrival_rbfkernelsvr.sav'
        # loading the model file from the storage
        loaded_model = pickle.load(open(filename, 'rb'))

        # pass to model to get prediction
        prediction = loaded_model.predict(
            df
        )

        print(prediction)

        # returning single prediction result to API CALLER
        # return jsonify({'Prediction': prediction[0]})

        # Returning full array of predictions to API CALLER
        response = {'prediction': []}
        response['prediction'] = list(prediction)
        return make_response(jsonify(response), 200)

        # return 'It worked well!'

    except Exception as e:
        print('The Exception message is: ', e)
        return 'something is wrong'


if __name__ == '__main__':
    app.run(debug=True)
